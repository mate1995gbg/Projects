﻿using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using Microsoft.EntityFrameworkCore;

namespace MauiAPI_MarcoTeranGutmanowitz_APR400.Data
{
    public class MauiDbContext : DbContext
    {
        public DbSet<Customer> customers { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<CustomerCarService> CustomerCarServices { get; set; }
        public MauiDbContext(DbContextOptions<MauiDbContext> options) : base(options)
        {   
        }
        public DbSet<MauiAPI_MarcoTeranGutmanowitz_APR400.Models.Sale> Sale { get; set; } = default!;
    }
}
