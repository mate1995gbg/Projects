﻿namespace MauiAPI_MarcoTeranGutmanowitz_APR400.Models
{
    public class CustomerCarService
    {
        public int CustomerCarServiceId { get; set; }
        public int ServiceId { get; set; }
        public int CustomerId { get; set; }
        public int CarId { get; set; }
        public DateTime ServiceDate { get; set; }
        public string ServiceDetails { get; set; }
        public bool IsOfTypeRecall { get; set; }

        public Customer Customer { get; set; }
        public Car Car { get; set; }
    }
}
