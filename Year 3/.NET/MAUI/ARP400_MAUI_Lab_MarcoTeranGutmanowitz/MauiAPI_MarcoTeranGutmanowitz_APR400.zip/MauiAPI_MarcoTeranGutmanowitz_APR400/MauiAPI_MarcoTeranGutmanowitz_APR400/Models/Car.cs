﻿namespace MauiAPI_MarcoTeranGutmanowitz_APR400.Models
{
    public class Car
    {
        public int CarId { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Engine { get; set; }
        public int ModelYear { get; set; }
        public string TrimLevel { get; set; }
        public double MsrpPrice { get; set; } /*should be double not float in order to match SQL servers "float" datatype!!*/
        public double AskingPrice { get; set; } /*should be double not float in order to match SQL servers "float" datatype!!*/
        public bool IsSold { get; set; }
        public string Vin {  get; set; }
        public string Color { get; set; }
        public string? CarDescription { get; set; }
        public DateTime DateArrivedAtLot { get; set; }
        public string? ImageUrl { get; set; }
    }
}
