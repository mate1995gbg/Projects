﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MauiAPI_MarcoTeranGutmanowitz_APR400.Data;
using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.Xml;

namespace MauiAPI_MarcoTeranGutmanowitz_APR400.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly IWebHostEnvironment env;

        private readonly MauiDbContext _context;

        public CarsController(MauiDbContext context, IWebHostEnvironment _env)
        {
            _context = context;
            env = _env;
        }

        // GET: api/Cars
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Car>>> GetCars()
        {
          if (_context.Cars == null)
          {
              return NotFound();
          }
            return await _context.Cars.ToListAsync();
        }

        // GET: api/Cars/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Car>> GetCar(int id)
        {
          if (_context.Cars == null)
          {
              return NotFound();
          }
            var car = await _context.Cars.FindAsync(id);

            if (car == null)
            {
                return NotFound();
            }

            return car;
        }

        // PUT: api/Cars/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCar(int id, Car car)
        {
            if (id != car.CarId)
            {
                return BadRequest();
            }

            _context.Entry(car).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Cars
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Car>> PostCar(Car car)
        {
          if (_context.Cars == null)
          {
              return Problem("Entity set 'MauiDbContext.Cars'  is null.");
          }
            _context.Cars.Add(car);
            await _context.SaveChangesAsync();

            //return CreatedAtAction("GetCar", new { id = car.CarId }, car);
            return Ok(car.CarId);
        }

        [HttpPost("{id}/UploadImage")]
        public async Task<ActionResult> PostCar(int id, IFormFile postedImage)
        {
            Car carWithImage = new Car();
            string[] allowedExtensions = { ".jpg", ".png", ".jpeg" };
            string[] allowedMimeTypes = { "image/jpeg", "image/png" };

            if (postedImage != null)
            {
                //perform file size and format checks
                if (postedImage.Length > 5000000)  //max 5 megabytes
                {
                    return BadRequest("File size is above 5 megabytes");
                }

                // File extension check
                string fileExtension = Path.GetExtension(postedImage.FileName).ToLower();
                if (!allowedExtensions.Contains(fileExtension))
                {
                    return BadRequest("Invalid file format, format not found in allowedExtensions");
                }

                // MIME type check
                string mimeType = postedImage.ContentType;
                if (!allowedMimeTypes.Contains(mimeType))
                {
                    return BadRequest("Invalid MIME file format, format not found in allowedMimeTypes");
                }

                string wwwPath = this.env.WebRootPath;
                Console.WriteLine($"wwwPath: {wwwPath}");
                string path = Path.Combine(wwwPath, "lib/images");

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string filename = Path.GetFileName(postedImage.FileName);
                using (FileStream stream = new FileStream(Path.Combine(path, filename), FileMode.Create))
                {
                    await postedImage.CopyToAsync(stream);
                }

                string imageUrl = Path.Combine("wwwroot", "lib", "images", filename);

                if (_context == null)
                {
                    return NotFound("Context not found.");
                }

                carWithImage = await _context.Cars.FindAsync(id);

                if (carWithImage == null)
                {
                    return NotFound("Car not found.");
                }

                carWithImage.ImageUrl = imageUrl;
                _context.Entry(carWithImage).State = EntityState.Modified;

                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return CreatedAtAction("GetCar", new { id = carWithImage.CarId }, carWithImage);
        }

        // DELETE: api/Cars/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCar(int id)
        {
            if (_context.Cars == null)
            {
                return NotFound();
            }
            var car = await _context.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }

            _context.Cars.Remove(car);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CarExists(int id)
        {
            return (_context.Cars?.Any(e => e.CarId == id)).GetValueOrDefault();
        }

        [HttpGet("GetImage/{carId}")] /*Signature i.e carId here must match inparameter of method!!!*/
        public async Task<IActionResult> GetImageAsync(int carId)
        {
            Car carObject = await _context.Cars.FindAsync(carId);
            if (carObject != null)
            {
                var path = carObject.ImageUrl;
                    if (path != null)
                {
                    var image = System.IO.File.OpenRead(path);
                    return File(image, "image/jpeg");
                }
                else
                {
                    return NotFound("car objects ImageUrl field is null or not found on server!");
                }
            }
            else
            {
                return NotFound("carObject not found!");
            }
       
        }
    }


}
