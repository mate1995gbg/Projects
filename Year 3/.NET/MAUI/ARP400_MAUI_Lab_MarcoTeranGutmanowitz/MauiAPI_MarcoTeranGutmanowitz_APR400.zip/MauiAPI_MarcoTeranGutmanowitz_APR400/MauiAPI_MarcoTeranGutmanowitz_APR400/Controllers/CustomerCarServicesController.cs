﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MauiAPI_MarcoTeranGutmanowitz_APR400.Data;
using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;

namespace MauiAPI_MarcoTeranGutmanowitz_APR400.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerCarServicesController : ControllerBase
    {
        private readonly MauiDbContext _context;

        public CustomerCarServicesController(MauiDbContext context)
        {
            _context = context;
        }

        // GET: api/CustomerCarServices
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerCarService>>> GetCustomerCarServices()
        {
          if (_context.CustomerCarServices == null)
          {
              return NotFound();
          }
            return await _context.CustomerCarServices.ToListAsync();
        }

        // GET: api/CustomerCarServices/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerCarService>> GetCustomerCarService(int id)
        {
          if (_context.CustomerCarServices == null)
          {
              return NotFound();
          }
            var customerCarService = await _context.CustomerCarServices.FindAsync(id);

            if (customerCarService == null)
            {
                return NotFound();
            }

            return customerCarService;
        }

        // PUT: api/CustomerCarServices/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCustomerCarService(int id, CustomerCarService customerCarService)
        {
            if (id != customerCarService.CustomerCarServiceId)
            {
                return BadRequest();
            }

            _context.Entry(customerCarService).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerCarServiceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CustomerCarServices
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CustomerCarService>> PostCustomerCarService(CustomerCarService customerCarService)
        {
          if (_context.CustomerCarServices == null)
          {
              return Problem("Entity set 'MauiDbContext.CustomerCarServices'  is null.");
          }
            _context.CustomerCarServices.Add(customerCarService);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCustomerCarService", new { id = customerCarService.CustomerCarServiceId }, customerCarService);
        }

        // DELETE: api/CustomerCarServices/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomerCarService(int id)
        {
            if (_context.CustomerCarServices == null)
            {
                return NotFound();
            }
            var customerCarService = await _context.CustomerCarServices.FindAsync(id);
            if (customerCarService == null)
            {
                return NotFound();
            }

            _context.CustomerCarServices.Remove(customerCarService);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CustomerCarServiceExists(int id)
        {
            return (_context.CustomerCarServices?.Any(e => e.CustomerCarServiceId == id)).GetValueOrDefault();
        }
    }
}
