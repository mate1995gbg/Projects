﻿using MauiApp1_MarcoTeranGutmanowitz_APR400.View;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCounterClicked(object sender, EventArgs e)
        {
            count++;

            if (count == 1)
                CounterBtn.Text = $"Clicked {count} time";
            else
                CounterBtn.Text = $"Clicked {count} times";

            SemanticScreenReader.Announce(CounterBtn.Text);
        }

        private async void GoToCarsPage(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CarsPage());
        }

        private async void GoToCustomersPage(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CustomersPage());
        }
    }
}