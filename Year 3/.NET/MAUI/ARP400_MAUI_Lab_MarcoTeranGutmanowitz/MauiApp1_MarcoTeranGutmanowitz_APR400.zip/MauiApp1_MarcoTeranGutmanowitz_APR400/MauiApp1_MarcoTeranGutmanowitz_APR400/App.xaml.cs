﻿namespace MauiApp1_MarcoTeranGutmanowitz_APR400
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new AppShell();
        }
    }
}