﻿namespace MauiApp1_MarcoTeranGutmanowitz_APR400
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}