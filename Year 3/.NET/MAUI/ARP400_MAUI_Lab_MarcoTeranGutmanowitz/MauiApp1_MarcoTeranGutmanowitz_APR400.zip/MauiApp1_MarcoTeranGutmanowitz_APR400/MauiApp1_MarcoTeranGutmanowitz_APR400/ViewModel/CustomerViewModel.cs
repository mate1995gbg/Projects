﻿using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.Services;
using MauiApp1_MarcoTeranGutmanowitz_APR400.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel
{
    public class CustomerViewModel : INotifyPropertyChanged
    {

        #region props

        private static CustomerViewModel _instance; 
        public static CustomerViewModel Instance 
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CustomerViewModel();
                }
                return _instance;
            }
        }

        private readonly ApiService _apiService = new ApiService();
        private ObservableCollection<Customer> _customers;
        public ICommand DeleteCustomerCommand { get; set; }
        public ICommand EditCustomerCommand { get; set; }

        public event EventHandler<Customer> OnEditCustomerRequested;  //declare event ViewModel-wide


        #endregion props


        public CustomerViewModel()
        {
            _customers = new ObservableCollection<Customer>();
            LoadCustomersAsync();

            DeleteCustomerCommand = new Command<Customer>(ExecuteDeleteCustomer);
            EditCustomerCommand = new Command<Customer>(ExecuteEditCustomer);
        }

        public ObservableCollection<Customer> Customers  // this is a property
        {
            get { return _customers; }
            set
            {
                if (_customers != value)
                {
                    _customers = value;
                    OnPropertyChanged(nameof(Customers));
                }
            }
        }

        #region private methods

        private async Task LoadCustomersAsync()
        {
            var customerList = await _apiService.GetCustomersAsync();
            Customers.Clear();
            foreach (var customer in customerList)
            {
                Customers.Add(customer);
            }
        }

        private void ExecuteEditCustomer(Customer customerToEdit) 
        {
            OnEditCustomerRequested?.Invoke(this, customerToEdit);  //raise event 
        }

        #endregion private methods

        #region public methods

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName) //This method is used to raise the PropertyChanged event. You call this method whenever a property changes to notify the UI about it.
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public async Task CreateCustomerAsync(Customer newCustomer)
        {
            var success = await _apiService.PostCustomerAsync(newCustomer);
            if (success == true)
            {
                await LoadCustomersAsync();
            }
        }

        public async void ExecuteDeleteCustomer(Customer customerToDelete) //need wrapper method otherwise ICommand doesnt work
        {
            await DeleteCustomerAsync(customerToDelete);
        }

        public async Task DeleteCustomerAsync(Customer customerToDelete)
        {
            var success = await _apiService.DeleteCustomerAsync(customerToDelete);

            if (success)
            {
                await LoadCustomersAsync();
            }
        }

        public async Task OpenEditCustomerModalAsync(Customer customerToEdit, INavigation navigation)
        {
            var editCustomerModal = new EditCustomerModal(customerToEdit);
            //editCarModal.BindingContext = car;

            await navigation.PushModalAsync(editCustomerModal);
        }

        public async Task EditCustomerAsync(Customer customerToEdit) //dont need wrapper method for this class since we are using EventHandler
        {
            var success = await _apiService.EditCustomerAsync(customerToEdit);
            if (success == true)
            {
                await LoadCustomersAsync();
            }
        }

        #endregion public methods
    }
}
