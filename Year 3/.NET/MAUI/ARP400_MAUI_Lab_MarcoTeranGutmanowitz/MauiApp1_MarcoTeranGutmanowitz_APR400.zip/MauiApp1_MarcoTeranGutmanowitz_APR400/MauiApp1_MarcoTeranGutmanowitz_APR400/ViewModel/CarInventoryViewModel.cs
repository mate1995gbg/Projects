﻿using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.Services;
using MauiApp1_MarcoTeranGutmanowitz_APR400.View;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Input;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel
{
    public class CarInventoryViewModel : INotifyPropertyChanged  //an interface that, when implemented, lets the object notify the UI layer about changes to its properties. This is essential for data binding in MVVM.
    {

        //private List<Car> _cars;
        //public List<Car> Cars
        //{
        //    get { return _cars;}
        //    set { _cars = value; OnPropertyChanged(nameof(Cars)); }
        //}
        // SEE -> List<T> is a basic collection but does not provide notifications when its elements are added, deleted, or modified.

        private static CarInventoryViewModel _instance;  //singleton ViewModel code 

        public static CarInventoryViewModel Instance //singleton ViewModel code 
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CarInventoryViewModel();
                }
                return _instance;
            }
        }

        private readonly ApiService _apiService = new ApiService();  

        private ObservableCollection<Car> _cars; //ObservableCollection<T> is generally preferred in MVVM for data binding because it notifies the UI about changes.

        public ICommand DeleteCarCommand { get; private set; } //for delete cars button in CarsPage.xaml
        public ICommand EditCarCommand { get; set; }


        public event EventHandler<Car> OnEditCarRequested; 

        public CarInventoryViewModel()  //ctor for class
        {
            _cars = new ObservableCollection<Car>();
            DeleteCarCommand = new Command<Car>(ExecuteDeleteCar);
            EditCarCommand = new Command<Car>(ExecuteEditCar);
            InitializeAsync();

        }

        public ObservableCollection<Car> Cars
        {
            get { return _cars; }
            set
            {
                if (_cars != value)
                {
                    _cars = value;
                    OnPropertyChanged(nameof(Cars));
                }
            }
        }

        private void ExecuteEditCar(Car car) //Car car is where the CommandParameter object gets bound to when Command is triggered from the button in CarsPage.xaml
        {
            OnEditCarRequested?.Invoke(this, car);
        }


        public async Task OpenEditCarModalAsync(Car car, INavigation navigation)
        {
            var editCarModal = new EditCarModal(car);
            //editCarModal.BindingContext = car;

            await navigation.PushModalAsync(editCarModal);
        }
        public async Task InitializeAsync()
        {
            await LoadCarsAsync();
        }

        //private async Task LoadCarsAsync() //problem with this method, only loads some images some of the time, problem with threads ?
        //{

        //    var carList = await _apiService.GetCarsAsync();
        //    Cars.Clear();
        //    foreach (var car in carList)
        //    {
        //        Cars.Add(car);
        //        if(car.ImageUrl != null)
        //        {
        //            try
        //            {
        //                var carImage = await FetchCarImage(car.CarId);

        //                    car.CarImage = carImage;
        //            }
        //            catch (Exception ex)
        //            {
        //                Debug.WriteLine("Something went wrong with the FetchImageAsync method during LoadCarsAsync! " + ex);
        //            }
        //        }
        //    }
        //}


        private async Task LoadImageForCar(Car car)
        {
            try
            {
                car.CarImage = await FetchCarImage(car.CarId);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Something went wrong with the FetchImageAsync method for car {car.CarId}: {ex}");
            }
        }

        private async Task LoadCarsAsync()
        {
            var carList = await _apiService.GetCarsAsync();
            var tasks = new List<Task>();

            // Prepare to fetch all images
            foreach (var car in carList)
            {
                if (car.ImageUrl != null)
                {
                    tasks.Add(LoadImageForCar(car));
                }
            }

            // Wait until all images are loaded
            await Task.WhenAll(tasks);

            // Now update the ObservableCollection
            Cars.Clear();
            foreach (var car in carList)
            {
                Cars.Add(car);
            }
        }


        public async Task CreateCarAsync(Car newCar, Stream imageToUpload, string imageFileName)
        {
           var success = await _apiService.PostCarAsync(newCar, imageToUpload, imageFileName);
           if (success == true)
            {
                await LoadCarsAsync();
            }
        }

        public async Task EditCarAsync(Car carToEdit)
        {
            var success = await _apiService.EditCarAsync(carToEdit);
            if (success == true)
            {
                await LoadCarsAsync();
            }
        }

        public async void ExecuteDeleteCar(Car carTodelete) //need wrapper method otherwise ICommand doesnt work
        {
            await DeleteCarAsync(carTodelete);
        }

        public async Task DeleteCarAsync(Car carToDelete)
        {
            var success = await _apiService.DeleteCarAsync(carToDelete);

            if (success)
            {
                Cars.Remove(carToDelete);
            }
        }
        
        public async Task<ImageSource> FetchCarImage(int carId)
        {
            var image = await _apiService.FetchImageAsync(carId);
            return image;
        }

        public event PropertyChangedEventHandler PropertyChanged; // This event is part of the INotifyPropertyChanged interface. It gets triggered whenever a property changes, and the UI will listen to this event to update itself.

        protected virtual void OnPropertyChanged(string propertyName) //This method is used to raise the PropertyChanged event. You call this method whenever a property changes to notify the UI about it.
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
