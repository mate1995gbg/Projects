﻿using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;
        public ApiService()
        {
            _httpClient = new HttpClient();
        }
        #region Car API methods
        public async Task<List<Car>> GetCarsAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("http://localhost:5095/api/Cars");
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    List<Car> serviceResponse = JsonSerializer.Deserialize<List<Car>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    return serviceResponse;
                }
                else
                {
                    throw new HttpRequestException($"Failed to get cars. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return null;
            }
            
        }

        public async Task<bool> PostCarAsync(Car newCar, Stream imageToUpload, string imageFileName)
        {
            if (newCar != null && imageToUpload != null)
            {
                StringContent carContent = new StringContent(JsonSerializer.Serialize(newCar),
                Encoding.UTF8, "application/json");
                try
                {

                    var carResponse = await _httpClient.PostAsync("http://localhost:5095/api/Cars", carContent); //send the serialized car to API
                    if (carResponse.IsSuccessStatusCode)
                    {
                        //var createdCar = JsonSerializer.Deserialize<Car>(await carResponse.Content.ReadAsStringAsync());
                        int createdCarId = int.Parse(await carResponse.Content.ReadAsStringAsync());
                        using (var imageContent = new MultipartFormDataContent())
                        {
                            var imageStreamContent = new StreamContent(imageToUpload);
                            imageStreamContent.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");

                            imageContent.Add(imageStreamContent, "postedImage", $"{imageFileName}");

                            var imageResponse = await _httpClient.PostAsync($"http://localhost:5095/api/Cars/{createdCarId}/UploadImage", imageContent);

                            if (imageResponse.IsSuccessStatusCode)
                            {
                                return true;
                            }
                            else
                            {
                                Debug.WriteLine(imageResponse.StatusCode);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        Debug.WriteLine(carResponse.StatusCode);
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    return false;
                }
            }
            else
            {
                Debug.WriteLine("either newCar is null or postedImage is null! (PostCarAsync)");
                return false;
            }
            
        }
        public async Task<bool> EditCarAsync(Car carToEdit)
        {
            StringContent content = new StringContent(JsonSerializer.Serialize(carToEdit),
                Encoding.UTF8, "application/json");

            try
            {
                var response = await _httpClient.PutAsync($"http://localhost:5095/api/Cars/{carToEdit.CarId}", content);

                if (response.IsSuccessStatusCode)
                {
                    return response.IsSuccessStatusCode;
                }
                else
                {
                    Debug.WriteLine(response.StatusCode);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        public async Task<bool> DeleteCarAsync(Car carToDelete)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("http://localhost:5095/api/Cars/" + carToDelete.CarId);
                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    Debug.WriteLine(" response recieved but failed: " + response.StatusCode);
                    return false;
                }
            }   
            catch (Exception ex)
            {
                Debug.WriteLine("Failed DeleteCarAsync, no response recieved or failed try block.");
                return false;
            }
        }

        public async Task<ImageSource> FetchImageAsync(int carId)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    var response = await httpClient.GetAsync($"http://localhost:5095/api/Cars/GetImage/" + carId);

                    if (response.IsSuccessStatusCode)
                    {
                        var imageBytes = await response.Content.ReadAsByteArrayAsync();
                        return ImageSource.FromStream(() => new MemoryStream(imageBytes));
                    }
                    else
                    {
                        Debug.WriteLine($"Failed to load image: {response.StatusCode}");
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error fetching image: {ex.Message}");
                return null;
            }
        }

        #endregion Car API methods

        #region Customer API methods
        public async Task<List<Customer>> GetCustomersAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("http://localhost:5095/api/Customers");
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    List<Customer> responseList = JsonSerializer.Deserialize<List<Customer>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    return responseList;
                }
                else
                {
                    throw new HttpRequestException($"Failed to get customers. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> PostCustomerAsync(Customer newCustomer)
        {
            StringContent content = new StringContent(JsonSerializer.Serialize(newCustomer),
                Encoding.UTF8, "application/json");
            try
            {
                var response = await _httpClient.PostAsync("http://localhost:5095/api/Customers", content);

                if (response.IsSuccessStatusCode)
                {
                    return response.IsSuccessStatusCode;
                }
                else
                {
                    Debug.WriteLine(response.StatusCode);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        public async Task<bool> EditCustomerAsync(Customer customerToEdit)
        {
            StringContent content = new StringContent(JsonSerializer.Serialize(customerToEdit),
                Encoding.UTF8, "application/json");

            try
            {
                var response = await _httpClient.PutAsync($"http://localhost:5095/api/Customers/{customerToEdit.CustomerId}", content);

                if (response.IsSuccessStatusCode)
                {
                    return response.IsSuccessStatusCode;
                }
                else
                {
                    Debug.WriteLine(response.StatusCode);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }

        public async Task<bool> DeleteCustomerAsync(Customer customerToDelete)
        {
            try
            {
                var response = await _httpClient.DeleteAsync("http://localhost:5095/api/Customers/" + customerToDelete.CustomerId);
                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    Debug.WriteLine(" response recieved but failed: " + response.StatusCode);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Failed DeleteCarAsync, no response recieved or failed try block.");
                return false;
            }
        }
        #endregion Customer API methods

    }
}
