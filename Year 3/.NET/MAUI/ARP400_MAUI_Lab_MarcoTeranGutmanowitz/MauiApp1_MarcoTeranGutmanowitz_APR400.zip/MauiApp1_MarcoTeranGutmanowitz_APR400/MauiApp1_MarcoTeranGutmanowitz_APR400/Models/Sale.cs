﻿namespace MauiAPI_MarcoTeranGutmanowitz_APR400.Models
{
    public class Sale
    {
        public int SaleId { get; set; }
        public int CustomerId { get; set; }
        public int CarId { get; set; }
        public DateTime SalesDate { get; set; }
        public float FinalPrice { get; set; }

        public Customer Customer { get; set; }
        public Car Car { get; set; }
    }
}
