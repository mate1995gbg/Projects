using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.View;

public partial class EditCarModal : ContentPage
{
    public Car carToEdit { get; set; }
	public EditCarModal(Car carToEdit)
	{
        this.carToEdit = carToEdit;
        InitializeComponent();
        this.BindingContext = CarInventoryViewModel.Instance;

        //Initiaize & bind UI components
        CarMakeEntry.Text = carToEdit.Make;
        CarModelEntry.Text = carToEdit.Model;
        CarEngineEntry.Text = carToEdit.Engine;
        CarModelYearEntry.Text = carToEdit.ModelYear.ToString();
        CarTrimLevelEntry.Text = carToEdit.TrimLevel.ToString();
        CarMsrpEntry.Text = carToEdit.MsrpPrice.ToString();
        CarAskingPriceEntry.Text = carToEdit.AskingPrice.ToString();
        IsSoldSwitch.IsToggled = carToEdit.IsSold;
        CarVinEntry.Text = carToEdit.Vin;
        CarColorEntry.Text = carToEdit.Color;
        CarDescriptionEntry.Text = carToEdit.CarDescription;
        CarDateArrivedEntry.Date = carToEdit.DateArrivedAtLot;
        CarImageUrlEntry.Text = carToEdit.ImageUrl;
    }

	public async void OnSubmitEditCarClicked(object sender, EventArgs e)
	{

        if (CarInventoryViewModel.Instance == null)
        {
            // Handle the error. Perhaps show an alert.
            return;
        }
        //bind stuff from markup page via x:Name to Car properties
        Car editedCar = new Car
        {
            CarId = carToEdit.CarId,
            Make = CarMakeEntry.Text,
            Model = CarModelEntry.Text,
            Engine = CarEngineEntry.Text,
            ModelYear = int.Parse(CarModelYearEntry.Text),
            TrimLevel = CarTrimLevelEntry.Text,
            MsrpPrice = double.Parse(CarMsrpEntry.Text),
            AskingPrice = double.Parse(CarAskingPriceEntry.Text),
            IsSold = false,
            Vin = CarVinEntry.Text,
            Color = CarColorEntry.Text,
            CarDescription = CarDescriptionEntry.Text,
            DateArrivedAtLot = CarDateArrivedEntry.Date,
            ImageUrl = CarImageUrlEntry.Text
        };

        var viewModel = BindingContext as CarInventoryViewModel;

        if (viewModel == null)
        {
            // Handle the error. Perhaps show an alert.
            return;
        }

        await viewModel.EditCarAsync(editedCar);

        //close modal
        await Navigation.PopModalAsync();
    }
}
