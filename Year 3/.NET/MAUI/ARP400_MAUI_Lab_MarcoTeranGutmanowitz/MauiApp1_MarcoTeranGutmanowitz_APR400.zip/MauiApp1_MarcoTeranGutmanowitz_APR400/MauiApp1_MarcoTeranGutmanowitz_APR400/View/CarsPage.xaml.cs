using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.View;
//this is the "code-behind file" of the XAML page. the the other part is called the "XAML markup page". 
public partial class CarsPage : ContentPage
{
	public CarsPage()
	{
        BindingContext = CarInventoryViewModel.Instance; //these should be above initializeComponent to avoid problems
        ((CarInventoryViewModel)BindingContext).OnEditCarRequested += OnEditCarRequested; //these should be above initializeComponent to avoid problems
        InitializeComponent();
	
    }


	async void OnAddCarButtonClicked(object sender, EventArgs e) //remove this and follow MVVM pattern before hand in!
	{
		var addCarModal = new AddCarModal();
		await Navigation.PushModalAsync(addCarModal);
	}

	private async void OnEditCarRequested(object sender, Car carToEdit)
	{
		await ((CarInventoryViewModel)BindingContext).OpenEditCarModalAsync(carToEdit, Navigation);
	}

}