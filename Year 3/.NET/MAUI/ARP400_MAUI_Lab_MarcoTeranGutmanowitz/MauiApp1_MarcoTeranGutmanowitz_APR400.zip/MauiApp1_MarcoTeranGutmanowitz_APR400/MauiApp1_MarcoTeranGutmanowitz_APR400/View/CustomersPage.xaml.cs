using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.View;

public partial class CustomersPage : ContentPage
{
	public CustomersPage()
	{
		BindingContext = CustomerViewModel.Instance;
        ((CustomerViewModel)BindingContext).OnEditCustomerRequested += OnEditCustomerRequested;  //subscribe to event
        InitializeComponent();
	}

    private async void OnEditCustomerRequested(object sender, Customer customerToEdit)
    {
        await ((CustomerViewModel)BindingContext).OpenEditCustomerModalAsync(customerToEdit, Navigation); //event handler method. must match signature specified in event declaration
    }

    async void CreateCustomer_Clicked(object sender, EventArgs e)
    {
        var addCustomerModal = new AddCustomerModal();
        await Navigation.PushModalAsync(addCustomerModal);
    }
}