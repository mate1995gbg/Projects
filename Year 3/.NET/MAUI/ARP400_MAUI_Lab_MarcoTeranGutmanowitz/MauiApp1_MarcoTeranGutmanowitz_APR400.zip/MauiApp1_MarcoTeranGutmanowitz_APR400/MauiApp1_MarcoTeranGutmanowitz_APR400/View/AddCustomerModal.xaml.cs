using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.View;

public partial class AddCustomerModal : ContentPage
{
	public AddCustomerModal()
	{
		InitializeComponent();
        this.BindingContext = CustomerViewModel.Instance;
    }


    async void OnSubmitCustomerClicked(object sender, EventArgs e)
    {

        //bind stuff from markup page via x:Name to Car properties
        Customer newCustomer = new Customer
        {
            FirstName = CustomerFirstNameEntry.Text,
            LastName = CustomerLastNameEntry.Text,
            Email = CustomerEmailEntry.Text,
            PhoneNumber = CustomerPhoneNumberEntry.Text
        };

        var viewModel = BindingContext as CustomerViewModel;

        if (viewModel == null)
        {
            // Handle the error. Perhaps show an alert.
            return;
        }

        await viewModel.CreateCustomerAsync(newCustomer);

        //close modal
        await Navigation.PopModalAsync();
    }
}