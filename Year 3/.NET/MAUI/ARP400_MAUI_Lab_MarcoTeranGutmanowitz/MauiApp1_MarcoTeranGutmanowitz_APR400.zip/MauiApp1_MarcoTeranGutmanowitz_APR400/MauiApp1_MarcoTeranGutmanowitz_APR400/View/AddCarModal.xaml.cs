using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.Services;
using MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.View;

public partial class AddCarModal : ContentPage
{
	string imageFileName;
	Stream imageStreamToUpload;
	ImageSource imageToUpload;
    public AddCarModal()
	{
        InitializeComponent();
        this.BindingContext = CarInventoryViewModel.Instance;  //have to add this for BindingContext to work correctly
        //When you set BindingContext to an instance of your ViewModel, you're essentially telling the page where to get its data from.

    }

	async void OnSubmitClicked(object sender, EventArgs e)
	{

        if (!int.TryParse(CarModelYearEntry.Text, out int modelYear) || 
			!double.TryParse(CarMsrpEntry.Text, out double msrpPrice) || 
			!double.TryParse(CarAskingPriceEntry.Text, out double askingPrice))
        {
            // Show error message
            return;
        }

        //bind stuff from markup page via x:Name to Car properties
        Car newCar = new Car
		{
			Make = CarMakeEntry.Text,
			Model = CarModelEntry.Text,
			Engine = CarEngineEntry.Text,
			ModelYear = int.Parse(CarModelYearEntry.Text),
			TrimLevel = CarTrimLevelEntry.Text,
			MsrpPrice = double.Parse(CarMsrpEntry.Text),
			AskingPrice = double.Parse(CarAskingPriceEntry.Text),
			IsSold = false,
			Vin = CarVinEntry.Text,
			Color = CarColorEntry.Text,
			CarDescription = CarDescriptionEntry.Text,
			DateArrivedAtLot = CarDateArrivedEntry.Date,
			//ImageUrl = CarImageUrlEntry.Text
		};

        var viewModel = BindingContext as CarInventoryViewModel;

        if (viewModel == null)
        {
            // Handle the error. Perhaps show an alert.
            return;
        }

        await viewModel.CreateCarAsync(newCar, imageStreamToUpload, imageFileName);

        //close modal
        await Navigation.PopModalAsync();
	}

	public async void OnUploadImageClicked(object sender, EventArgs e)
	{
		var file = await FilePicker.PickAsync(new PickOptions
		{
			FileTypes = FilePickerFileType.Images,
			PickerTitle = "Pick an image"
		});

			if (file != null)
			{
				if (file.FileName.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) || file.FileName.EndsWith("png", StringComparison.OrdinalIgnoreCase))
				{
					imageStreamToUpload = await file.OpenReadAsync();
					var image = ImageSource.FromStream(() => imageStreamToUpload); //convert stream to ImageSource for display before submitting form (if u want)
					imageToUpload = image;
					imageFileName = file.FileName;
				}
			}
	}
}