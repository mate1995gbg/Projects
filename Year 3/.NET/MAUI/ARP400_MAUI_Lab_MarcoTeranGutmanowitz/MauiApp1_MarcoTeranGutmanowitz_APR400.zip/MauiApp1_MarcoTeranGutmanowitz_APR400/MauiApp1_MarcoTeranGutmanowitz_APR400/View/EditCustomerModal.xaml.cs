using MauiAPI_MarcoTeranGutmanowitz_APR400.Models;
using MauiApp1_MarcoTeranGutmanowitz_APR400.ViewModel;

namespace MauiApp1_MarcoTeranGutmanowitz_APR400.View;

public partial class EditCustomerModal : ContentPage
{
	public Customer customerToEdit { get; set; }	

	public EditCustomerModal(Customer customerToEdit)
	{
        this.customerToEdit = customerToEdit;
		InitializeComponent();
		this.BindingContext = CustomerViewModel.Instance;


		CustomerFirstNameEntry.Text = customerToEdit.FirstName;
		CustomerLastNameEntry.Text = customerToEdit.LastName;
		CustomerEmailEntry.Text = customerToEdit.Email;
		CustomerPhoneNumberEntry.Text = customerToEdit.PhoneNumber;
	}


	public async void OnEditCustomerClicked(object sender, EventArgs e)
	{

        if (CustomerViewModel.Instance == null)
        {
            // Handle the error. Perhaps show an alert.
            return;
        }
        //bind stuff from markup page via x:Name to Car properties
        Customer editedCustomer = new Customer
        {
            CustomerId = customerToEdit.CustomerId,
            FirstName = CustomerFirstNameEntry.Text,
            LastName = CustomerLastNameEntry.Text,
            Email = CustomerEmailEntry.Text,
            PhoneNumber = CustomerPhoneNumberEntry.Text
        };

        var viewModel = BindingContext as CustomerViewModel;

        if (viewModel == null)
        {
            // Handle the error. Perhaps show an alert.
            return;
        }

        await viewModel.EditCustomerAsync(editedCustomer);

        //close modal
        await Navigation.PopModalAsync();
    }
}